// for linux and mac //client
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define PORT 8080

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    char buffer[256];
    int client_exit = 0, server_exit = 0; // Flags for exit condition
    int verified = 0;  // Flag for ID verification status

    // Step 1: Create the client socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT); // Connect to port 8080
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Connect to localhost

    // Step 2: Connect to the server
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        exit(1);
    }

    // Step 3: Receive unique ID prompt
    memset(buffer, 0, sizeof(buffer));
    recv(client_socket, buffer, sizeof(buffer), 0);
    printf("%s", buffer);  // Display "Enter this unique ID: 5555"

    // Step 4: Wait for verification from the server
    while (!verified) {
        memset(buffer, 0, sizeof(buffer));
        recv(client_socket, buffer, sizeof(buffer), 0);

        if (strstr(buffer, "ID verified") != NULL) {
            printf("%s", buffer);  // Display verification message and exit instructions
            verified = 1;
        }
    }

    // Step 5: Chat communication after verification
    while (1) {
        memset(buffer, 0, sizeof(buffer));

        // Client sends message
        printf("Client: ");
        fgets(buffer, sizeof(buffer), stdin);
        buffer[strcspn(buffer, "\n")] = '\0';  // Remove newline character

        if (strcasecmp(buffer, "BYE") == 0) {
            client_exit = 1;
            send(client_socket, "BYE", strlen("BYE"), 0);
            if (server_exit) break;  // Exit if both have entered "BYE"
        } else {
            client_exit = 0;
            send(client_socket, buffer, strlen(buffer), 0);
        }

        // Client receives message from server
        memset(buffer, 0, sizeof(buffer));
        recv(client_socket, buffer, sizeof(buffer), 0);
        if (strcasecmp(buffer, "BYE") == 0) {
            server_exit = 1;
            if (client_exit) break;  // Exit if both have entered "BYE"
        } else {
            server_exit = 0;
            printf("Server: %s\n", buffer);
        }
    }

    // End the conversation
    printf("**** THANK YOU FOR USING😁, BY \"PM JI\". GOOD BYE🙂 ****\n");
    close(client_socket);
    return 0;
}